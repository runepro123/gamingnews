CKEDITOR.editorConfig = function( config ) {
    config.extraPlugins = ['youtube','base64image'];

}